// ══════════════════════════════════════════════
//  nav.js — Navigation & Modal Helpers
// ══════════════════════════════════════════════

// ── Page Navigation ───────────────────────────

/**
 * Switch the visible page panel and update the active nav item.
 * @param {string} page - Page key (e.g. 'dashboard', 'sites')
 * @param {HTMLElement} el - The clicked nav item element
 */
function navigate(page, el) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));

  document.getElementById('page-' + page).classList.add('active');
  if (el) el.classList.add('active');
  document.getElementById('breadcrumb').textContent =
    page.charAt(0).toUpperCase() + page.slice(1);

  // Pre-populate dropdowns for pages that need live data
  if (page === 'tasks') populateTaskModalDropdowns();
  if (page === 'attendance' || page === 'salary') populateAttDropdowns();
}

// ── Modal Helpers ─────────────────────────────

/**
 * Open a modal overlay by ID.
 * Populates relevant dropdowns before showing.
 */
function openModal(id) {
  if (id === 'addTaskModal') populateTaskModalDropdowns();
  if (['markAttModal', 'allocateModal', 'salaryModal'].includes(id)) populateAttDropdowns();
  document.getElementById(id).classList.add('show');
}

/**
 * Close a modal overlay by ID.
 */
function closeModal(id) {
  document.getElementById(id).classList.remove('show');
}

// Close modal when clicking outside the modal box
document.addEventListener('click', e => {
  if (e.target.classList.contains('modal-overlay')) {
    e.target.classList.remove('show');
  }
});

// ── Dropdown Populators ───────────────────────

/**
 * Populate site and worker dropdowns used in the Add Task modal.
 */
function populateTaskModalDropdowns() {
  document.getElementById('tSite').innerHTML =
    DB.sites
      .filter(s => s.status === 'ACTIVE')
      .map(s => `<option value="${s.id}">${s.name}</option>`)
      .join('');

  document.getElementById('tWorker').innerHTML =
    '<option value="">Unassigned</option>' +
    DB.workers
      .filter(w => w.status === 'ACTIVE')
      .map(w => `<option value="${w.id}">${w.name} (${w.type})</option>`)
      .join('');
}

/**
 * Populate worker and site dropdowns used in Attendance, Allocate,
 * and Salary modals. Also pre-fills date fields with today.
 */
function populateAttDropdowns() {
  const workerOptions = DB.workers
    .filter(w => w.status === 'ACTIVE')
    .map(w => `<option value="${w.id}">${w.name}</option>`)
    .join('');

  const siteOptions = DB.sites
    .filter(s => s.status === 'ACTIVE')
    .map(s => `<option value="${s.id}">${s.name}</option>`)
    .join('');

  ['attWorker', 'allocWorker', 'salWorker'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.innerHTML = workerOptions;
  });

  ['attSite', 'allocSite', 'salSite'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.innerHTML = siteOptions;
  });

  const today = new Date().toISOString().split('T')[0];
  ['attDate', 'allocDate'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = today;
  });
}
