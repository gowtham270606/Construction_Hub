// ══════════════════════════════════════════════
//  auth.js — Authentication
// ══════════════════════════════════════════════

/**
 * Authenticate user from the sign-in form.
 * On success: hides sign-in page, shows app shell.
 */
function doSignIn() {
  const username = document.getElementById('siUsername').value.trim();
  const password = document.getElementById('siPassword').value;

  const user = DB.users.find(
    x => x.username.toLowerCase() === username.toLowerCase() && x.password === password
  );

  if (!user) {
    const err = document.getElementById('siError');
    err.textContent = 'Invalid username or password.';
    err.style.display = 'block';
    return;
  }

  DB.currentUser = user;
  document.getElementById('signinPage').style.display = 'none';
  document.getElementById('appShell').style.display = 'flex';
  setupUserUI();
  renderAll();
}

/**
 * Sign out current user and return to sign-in screen.
 */
function doSignOut() {
  DB.currentUser = null;
  document.getElementById('appShell').style.display = 'none';
  document.getElementById('signinPage').style.display = 'flex';
  document.getElementById('siPassword').value = '';
}

/**
 * Configure the sidebar and quick-action visibility based on role.
 */
function setupUserUI() {
  const user = DB.currentUser;
  document.getElementById('userAvatar').textContent = user.name[0].toUpperCase();
  document.getElementById('userName').textContent = user.name;
  document.getElementById('userRole').textContent = user.role;

  const isOwner = user.role === 'OWNER';
  document.getElementById('adminNavLabel').style.display = isOwner ? '' : 'none';
  document.getElementById('navSupervisor').style.display = isOwner ? '' : 'none';
  document.getElementById('siteAddBtn').style.display    = isOwner ? '' : 'none';
  document.getElementById('qaSupervisor').style.display  = isOwner ? '' : 'none';
}
