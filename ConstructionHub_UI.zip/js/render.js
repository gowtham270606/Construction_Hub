// ══════════════════════════════════════════════
//  render.js — DOM Rendering Functions
// ══════════════════════════════════════════════

/**
 * Re-render all pages and update all badges.
 * Called once after sign-in and after any data mutation.
 */
function renderAll() {
  renderSites();
  renderWorkers();
  renderTasks();
  renderAttendance();
  renderSalary();
  renderSupervisors();
  renderSiteProgress();
  updateBadges();
}

// ── Badges & Topbar Counters ──────────────────

function updateBadges() {
  const activeSites   = DB.sites.filter(s => s.status === 'ACTIVE').length;
  const activeWorkers = DB.workers.filter(w => w.status === 'ACTIVE').length;
  const openTasks     = DB.tasks.filter(t => t.status !== 'COMPLETED').length;
  const pendingTasks  = DB.tasks.filter(t => t.status === 'PENDING').length;

  document.getElementById('navSiteBadge').textContent   = activeSites;
  document.getElementById('navWorkerBadge').textContent = activeWorkers;
  document.getElementById('navTaskBadge').textContent   = DB.tasks.length;

  document.getElementById('tbSites').textContent   = activeSites;
  document.getElementById('tbWorkers').textContent = activeWorkers;
  document.getElementById('tbTasks').textContent   = openTasks;

  document.getElementById('dSites').textContent   = activeSites;
  document.getElementById('dWorkers').textContent = DB.workers.length;
  document.getElementById('dTasks').textContent   = pendingTasks;
}

// ── Sites Page ────────────────────────────────

function renderSites() {
  const tbody = document.getElementById('sitesTable');
  if (!DB.sites.length) {
    tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;color:var(--muted);padding:32px">No sites found</td></tr>';
    return;
  }
  tbody.innerHTML = DB.sites.map(s => `
    <tr>
      <td class="mono">#${s.id}</td>
      <td><strong>${s.name}</strong></td>
      <td>${s.location}</td>
      <td>${badgeFor(s.status)}</td>
      <td class="mono">${s.startDate}</td>
      <td class="mono">${s.endDate || '—'}</td>
      <td>
        ${s.status === 'ACTIVE' && DB.currentUser?.role === 'OWNER'
          ? `<button class="btn btn-sm btn-ghost" onclick="markSiteComplete(${s.id})">Mark Complete</button>`
          : ''}
      </td>
    </tr>`).join('');
}

// ── Workers Page ──────────────────────────────

function renderWorkers() {
  const tbody = document.getElementById('workersTable');
  tbody.innerHTML = DB.workers.map(w => `
    <tr>
      <td class="mono">${w.workerId}</td>
      <td><strong>${w.name}</strong></td>
      <td>${w.type}</td>
      <td class="mono">₹${w.dailyWage}/day</td>
      <td>${badgeFor(w.status)}</td>
      <td>
        ${w.status === 'ACTIVE'
          ? `<button class="btn btn-sm btn-danger" onclick="deactivateWorker(${w.id})">Deactivate</button>`
          : '<span style="color:var(--muted2);font-size:0.75rem">Inactive</span>'}
      </td>
    </tr>`).join('');
}

// ── Tasks Page ────────────────────────────────

function renderTasks() {
  const tbody = document.getElementById('tasksTable');
  tbody.innerHTML = DB.tasks.map(t => {
    const site   = DB.sites.find(s => s.id === t.siteId);
    const worker = t.workerId ? DB.workers.find(w => w.id === t.workerId) : null;
    return `<tr>
      <td class="mono">#${t.id}</td>
      <td>${site?.name || '—'}</td>
      <td>${worker ? worker.name : '<span style="color:var(--muted)">Unassigned</span>'}</td>
      <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${t.description}</td>
      <td>${badgeFor(t.status)}</td>
      <td class="mono">${t.deadline || '—'}</td>
      <td><button class="btn btn-sm btn-ghost" onclick="openUpdateTask(${t.id})">Update</button></td>
    </tr>`;
  }).join('');
}

// ── Attendance Page ───────────────────────────

function renderAttendance() {
  // Calendar grid — May 2026
  const grid = document.getElementById('attGrid');
  grid.innerHTML = '';
  for (let d = 1; d <= 31; d++) {
    const dateStr = `${String(d).padStart(2, '0')}-05-2026`;
    const rec = DB.attendance.find(a => a.date === dateStr);
    const cls = rec ? (rec.present ? 'present' : 'absent') : 'empty';
    const div = document.createElement('div');
    div.className = `att-day ${cls}`;
    div.textContent = d;
    div.title = dateStr;
    grid.appendChild(div);
  }

  // Attendance records table
  const tbody = document.getElementById('attTable');
  tbody.innerHTML = DB.attendance.map(a => {
    const w = DB.workers.find(x => x.id === a.workerId);
    const s = DB.sites.find(x => x.id === a.siteId);
    return `<tr>
      <td>${w?.name || '—'} <span class="mono" style="color:var(--muted)">${w?.workerId}</span></td>
      <td>${s?.name || '—'}</td>
      <td class="mono">${a.date}</td>
      <td>${a.present
        ? '<span class="badge badge-active">Present</span>'
        : '<span class="badge badge-inactive">Absent</span>'}</td>
    </tr>`;
  }).join('');
}

// ── Salary Page ───────────────────────────────

function renderSalary() {
  const el = document.getElementById('salaryList');
  if (!DB.salaries.length) {
    el.innerHTML = '<div style="padding:24px;text-align:center;color:var(--muted)">No salary records</div>';
    return;
  }
  el.innerHTML = DB.salaries.map(s => {
    const worker = DB.workers.find(x => x.id === s.workerId);
    const site   = DB.sites.find(x => x.id === s.siteId);
    return `<div class="salary-row">
      <div>
        <div style="font-weight:500">${worker?.name}</div>
        <div class="mono" style="font-size:0.65rem;color:var(--muted)">
          ${site?.name} · ${s.weekStart} – ${s.weekEnd} · ${s.totalDays} days
        </div>
      </div>
      <div class="s-value" style="color:var(--green)">₹${s.totalAmount.toLocaleString()}</div>
    </div>`;
  }).join('');
}

// ── Supervisors Page ──────────────────────────

function renderSupervisors() {
  const tbody = document.getElementById('supervisorsTable');
  const supervisors = DB.users.filter(u => u.role === 'SUPERVISOR');
  tbody.innerHTML = supervisors.length
    ? supervisors.map(u => `<tr>
        <td class="mono">#${u.id}</td>
        <td><strong>${u.name}</strong></td>
        <td class="mono">${u.username}</td>
        <td>${badgeFor('ACTIVE')}</td>
        <td class="mono">${u.createdAt}</td>
      </tr>`).join('')
    : '<tr><td colspan="5" style="text-align:center;color:var(--muted);padding:32px">No supervisors yet. Owner can add supervisors.</td></tr>';
}

// ── Dashboard: Site Progress ──────────────────

function renderSiteProgress() {
  const el = document.getElementById('siteProgressList');
  el.innerHTML = DB.sites.map(s => {
    const siteTasks = DB.tasks.filter(t => t.siteId === s.id);
    const done = siteTasks.filter(t => t.status === 'COMPLETED').length;
    const pct  = siteTasks.length ? Math.round(done / siteTasks.length * 100) : 0;
    const color = s.status === 'COMPLETED' ? 'var(--blue)'
                : pct > 60               ? 'var(--green)'
                :                          'var(--accent)';
    return `<div style="padding:14px 20px;border-bottom:1px solid var(--border)">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
        <div style="font-size:0.875rem;font-weight:500">
          ${s.name} <span style="color:var(--muted);font-size:0.75rem">· ${s.location}</span>
        </div>
        <div style="display:flex;align-items:center;gap:10px">
          ${badgeFor(s.status)}
          <span style="font-family:var(--mono);font-size:0.7rem;color:var(--muted)">${done}/${siteTasks.length} tasks</span>
          <span style="font-family:var(--mono);font-size:0.75rem;color:${color}">${pct}%</span>
        </div>
      </div>
      <div class="progress-bar">
        <div class="progress-fill" style="width:${pct}%;background:${color}"></div>
      </div>
    </div>`;
  }).join('');
}
