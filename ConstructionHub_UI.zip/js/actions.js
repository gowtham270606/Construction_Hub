// ══════════════════════════════════════════════
//  actions.js — Form Action Handlers
// ══════════════════════════════════════════════

// ── Sites ─────────────────────────────────────

function addSite() {
  const name  = document.getElementById('sName').value.trim();
  const loc   = document.getElementById('sLocation').value.trim();
  const start = document.getElementById('sStart').value;
  const end   = document.getElementById('sEnd').value;

  if (!name || name.length < 3) { toast('Site name must be at least 3 characters', 'error'); return; }
  if (!loc)                     { toast('Location cannot be empty', 'error'); return; }
  if (!start)                   { toast('Start date is required', 'error'); return; }

  DB.sites.push({
    id:        DB.nextId.site++,
    name,
    location:  loc,
    status:    'ACTIVE',
    startDate: formatDate(start),
    endDate:   end ? formatDate(end) : ''
  });

  // Reset form fields
  ['sName', 'sLocation', 'sStart', 'sEnd'].forEach(id => document.getElementById(id).value = '');

  closeModal('addSiteModal');
  renderSites();
  renderSiteProgress();
  updateBadges();
  toast(`Site "${name}" added`, 'success');
}

function markSiteComplete(id) {
  const site = DB.sites.find(x => x.id === id);
  if (!site) return;
  site.status = 'COMPLETED';
  renderSites();
  renderSiteProgress();
  updateBadges();
  toast('Site marked as Completed', 'success');
}

// ── Workers ───────────────────────────────────

function addWorker() {
  const name = document.getElementById('wName').value.trim();
  const type = document.getElementById('wType').value;
  const wage = parseFloat(document.getElementById('wWage').value);

  if (!name)          { toast('Name cannot be empty', 'error'); return; }
  if (!type)          { toast('Please select a trade', 'error'); return; }
  if (!wage || wage <= 0) { toast('Daily wage must be a positive number', 'error'); return; }

  const id = DB.nextId.worker++;
  DB.workers.push({
    id,
    workerId:  `WRK${String(id).padStart(4, '0')}`,
    name,
    type,
    dailyWage: wage,
    status:    'ACTIVE'
  });

  ['wName', 'wWage'].forEach(elId => document.getElementById(elId).value = '');
  document.getElementById('wType').value = '';

  closeModal('addWorkerModal');
  renderWorkers();
  updateBadges();
  toast(`Worker "${name}" added`, 'success');
}

function deactivateWorker(id) {
  const worker = DB.workers.find(x => x.id === id);
  if (!worker) return;
  worker.status = 'INACTIVE';
  renderWorkers();
  updateBadges();
  toast(`${worker.name} deactivated`, 'success');
}

// ── Tasks ─────────────────────────────────────

function addTask() {
  const siteId   = parseInt(document.getElementById('tSite').value);
  const workerEl = document.getElementById('tWorker').value;
  const workerId = workerEl ? parseInt(workerEl) : null;
  const desc     = document.getElementById('tDesc').value.trim();
  const deadline = document.getElementById('tDeadline').value;

  if (!siteId)              { toast('Please select a site', 'error'); return; }
  if (!desc || desc.length < 5) { toast('Description must be at least 5 characters', 'error'); return; }

  DB.tasks.push({
    id:          DB.nextId.task++,
    siteId,
    workerId,
    description: desc,
    status:      'PENDING',
    deadline:    deadline ? formatDate(deadline) : ''
  });

  ['tDesc', 'tDeadline'].forEach(id => document.getElementById(id).value = '');

  closeModal('addTaskModal');
  renderTasks();
  updateBadges();
  toast('Task created', 'success');
}

function openUpdateTask(id) {
  const task = DB.tasks.find(x => x.id === id);
  if (!task) return;
  document.getElementById('taskUpdateId').value = id;
  document.getElementById('taskNewStatus').value = task.status;
  openModal('updateTaskModal');
}

function updateTaskStatus() {
  const id     = parseInt(document.getElementById('taskUpdateId').value);
  const status = document.getElementById('taskNewStatus').value;
  const task   = DB.tasks.find(x => x.id === id);
  if (!task) return;
  task.status = status;
  renderTasks();
  updateBadges();
  closeModal('updateTaskModal');
  toast('Task status updated', 'success');
}

// ── Attendance ────────────────────────────────

function markAttendance() {
  const workerId = parseInt(document.getElementById('attWorker').value);
  const siteId   = parseInt(document.getElementById('attSite').value);
  const date     = document.getElementById('attDate').value;
  const present  = document.getElementById('attStatus').value === 'present';

  if (!workerId || !siteId || !date) { toast('Please fill all fields', 'error'); return; }

  const dateStr = formatDate(date);
  const duplicate = DB.attendance.find(
    a => a.workerId === workerId && a.siteId === siteId && a.date === dateStr
  );
  if (duplicate) { toast('Attendance already marked for this worker on this date', 'error'); return; }

  DB.attendance.push({ id: DB.nextId.att++, workerId, siteId, date: dateStr, present });

  closeModal('markAttModal');
  renderAttendance();
  toast(`Attendance marked: ${present ? 'Present' : 'Absent'}`, 'success');
}

function allocateWorker() {
  const workerId = parseInt(document.getElementById('allocWorker').value);
  const siteId   = parseInt(document.getElementById('allocSite').value);
  const date     = document.getElementById('allocDate').value;

  if (!workerId || !siteId || !date) { toast('Please fill all fields', 'error'); return; }

  closeModal('allocateModal');
  toast('Worker allocated successfully', 'success');
}

// ── Salary ────────────────────────────────────

function paySalary() {
  const workerId = parseInt(document.getElementById('salWorker').value);
  const siteId   = parseInt(document.getElementById('salSite').value);
  const from     = document.getElementById('salFrom').value;
  const to       = document.getElementById('salTo').value;

  if (!workerId || !siteId || !from || !to) { toast('Please fill all fields', 'error'); return; }

  const worker = DB.workers.find(x => x.id === workerId);
  const days   = Math.round(Math.random() * 4 + 3); // demo: 3–7 present days
  const total  = days * worker.dailyWage;

  DB.salaries.push({
    id:          DB.nextId.sal++,
    workerId,
    siteId,
    totalDays:   days,
    totalAmount: total,
    weekStart:   formatDate(from),
    weekEnd:     formatDate(to)
  });

  closeModal('salaryModal');
  renderSalary();
  toast(`₹${total.toLocaleString()} paid to ${worker.name} (${days} days)`, 'success');
}

// ── Supervisors ───────────────────────────────

function addSupervisor() {
  const name     = document.getElementById('supName').value.trim();
  const username = document.getElementById('supUsername').value.trim();
  const password = document.getElementById('supPassword').value;

  if (!name)              { toast('Name cannot be empty', 'error'); return; }
  if (username.length < 3){ toast('Username must be at least 3 characters', 'error'); return; }
  if (DB.users.find(u => u.username.toLowerCase() === username.toLowerCase()))
                          { toast('Username already taken', 'error'); return; }
  if (password.length < 6){ toast('Password must be at least 6 characters', 'error'); return; }

  DB.users.push({
    id:        DB.nextId.user++,
    name,
    username,
    password,
    role:      'SUPERVISOR',
    createdAt: todayLabel()
  });

  ['supName', 'supUsername', 'supPassword'].forEach(id => document.getElementById(id).value = '');

  closeModal('addSupervisorModal');
  renderSupervisors();
  toast(`Supervisor "${name}" created`, 'success');
}
