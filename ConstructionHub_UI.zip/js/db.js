// ══════════════════════════════════════════════
//  db.js — In-Memory Data Store
// ══════════════════════════════════════════════

const DB = {
  currentUser: null,

  users: [
    { id: 1, name: 'Admin', username: 'admin', password: 'admin123', role: 'OWNER', createdAt: '01-05-2026' }
  ],

  sites: [
    { id: 1, name: 'Site Alpha', location: 'Chennai, TN',     status: 'ACTIVE',    startDate: '01-04-2026', endDate: '31-12-2026' },
    { id: 2, name: 'Site Beta',  location: 'Coimbatore, TN',  status: 'ACTIVE',    startDate: '15-03-2026', endDate: '30-09-2026' },
    { id: 3, name: 'Site Gamma', location: 'Madurai, TN',     status: 'COMPLETED', startDate: '01-01-2026', endDate: '30-04-2026' },
  ],

  workers: [
    { id: 1, workerId: 'WRK0001', name: 'Ravi Kumar', type: 'Mason',       dailyWage: 900,  status: 'ACTIVE'   },
    { id: 2, workerId: 'WRK0002', name: 'Senthil',    type: 'Electrician', dailyWage: 1100, status: 'ACTIVE'   },
    { id: 3, workerId: 'WRK0003', name: 'Murugan',    type: 'Plumber',     dailyWage: 850,  status: 'INACTIVE' },
    { id: 4, workerId: 'WRK0004', name: 'Arjun',      type: 'Carpenter',   dailyWage: 800,  status: 'ACTIVE'   },
    { id: 5, workerId: 'WRK0005', name: 'Gopal',      type: 'Painter',     dailyWage: 750,  status: 'ACTIVE'   },
    { id: 6, workerId: 'WRK0006', name: 'Suresh',     type: 'Helper',      dailyWage: 600,  status: 'ACTIVE'   },
  ],

  tasks: [
    { id: 1, siteId: 1, workerId: 1,    description: 'Foundation laying for Block A', status: 'COMPLETED',   deadline: '15-04-2026' },
    { id: 2, siteId: 1, workerId: 2,    description: 'Electrical wiring - Floor 1',   status: 'IN_PROGRESS', deadline: '20-05-2026' },
    { id: 3, siteId: 1, workerId: null, description: 'Plumbing installation',          status: 'PENDING',     deadline: '25-05-2026' },
    { id: 4, siteId: 2, workerId: 4,    description: 'Roof framework construction',    status: 'IN_PROGRESS', deadline: '10-05-2026' },
    { id: 5, siteId: 2, workerId: 5,    description: 'Interior paint - Level 2',       status: 'PENDING',     deadline: '01-06-2026' },
    { id: 6, siteId: 1, workerId: 6,    description: 'Material unloading & storage',   status: 'COMPLETED',   deadline: '01-05-2026' },
    { id: 7, siteId: 2, workerId: 1,    description: 'Brick masonry - East wall',      status: 'PENDING',     deadline: '15-06-2026' },
    { id: 8, siteId: 1, workerId: 2,    description: 'Generator room wiring',          status: 'PENDING',     deadline: '30-05-2026' },
  ],

  attendance: [
    { id: 1, workerId: 1, siteId: 1, date: '06-05-2026', present: true  },
    { id: 2, workerId: 2, siteId: 1, date: '06-05-2026', present: true  },
    { id: 3, workerId: 4, siteId: 2, date: '06-05-2026', present: false },
    { id: 4, workerId: 5, siteId: 2, date: '06-05-2026', present: true  },
    { id: 5, workerId: 1, siteId: 1, date: '07-05-2026', present: true  },
    { id: 6, workerId: 6, siteId: 1, date: '07-05-2026', present: true  },
  ],

  salaries: [
    { id: 1, workerId: 1, siteId: 1, totalDays: 5, totalAmount: 4500, weekStart: '28-04-2026', weekEnd: '04-05-2026' },
    { id: 2, workerId: 2, siteId: 1, totalDays: 5, totalAmount: 5500, weekStart: '28-04-2026', weekEnd: '04-05-2026' },
    { id: 3, workerId: 4, siteId: 2, totalDays: 4, totalAmount: 3200, weekStart: '28-04-2026', weekEnd: '04-05-2026' },
  ],

  nextId: { site: 4, worker: 7, task: 9, att: 7, sal: 4, user: 2 }
};
