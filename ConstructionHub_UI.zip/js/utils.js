// ══════════════════════════════════════════════
//  utils.js — Shared Utilities
// ══════════════════════════════════════════════

// ── Date Helpers ──────────────────────────────

/**
 * Convert ISO date (YYYY-MM-DD) → dd-MM-yyyy
 */
function formatDate(iso) {
  if (!iso) return '';
  const [y, m, d] = iso.split('-');
  return `${d}-${m}-${y}`;
}

/**
 * Return today as dd-MM-yyyy
 */
function todayLabel() {
  const d = new Date();
  return [
    String(d.getDate()).padStart(2, '0'),
    String(d.getMonth() + 1).padStart(2, '0'),
    d.getFullYear()
  ].join('-');
}

// ── Badge Helper ──────────────────────────────

/**
 * Return a status badge HTML string for a given status key.
 */
function badgeFor(status) {
  const classMap = {
    ACTIVE:      'badge-active',
    INACTIVE:    'badge-inactive',
    COMPLETED:   'badge-complete',
    PENDING:     'badge-pending',
    IN_PROGRESS: 'badge-progress'
  };
  const labelMap = { IN_PROGRESS: 'In Progress' };
  const label = labelMap[status] || status;
  return `<span class="badge ${classMap[status] || ''}">${label}</span>`;
}

// ── Toast ─────────────────────────────────────

/**
 * Show a temporary notification toast.
 * @param {string} msg   - Message to display
 * @param {'success'|'error'} type
 */
function toast(msg, type = 'success') {
  const container = document.getElementById('toastContainer');
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.innerHTML = `<span class="toast-icon">${type === 'success' ? '✓' : '✕'}</span>${msg}`;
  container.appendChild(el);
  setTimeout(() => {
    el.style.opacity = '0';
    el.style.transform = 'translateX(20px)';
    el.style.transition = 'all 0.3s';
    setTimeout(() => el.remove(), 300);
  }, 3000);
}
